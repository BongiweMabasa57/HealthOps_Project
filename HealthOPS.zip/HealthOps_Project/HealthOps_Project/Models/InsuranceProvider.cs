namespace HealthOps_Project.Models
{
    public class InsuranceProvider
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
